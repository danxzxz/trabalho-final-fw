<?php
$mensagens = ['Erro 0: No foi possível criar diretórios ',
    'Erro 1: Falha ao conectar ao banco de dados'];