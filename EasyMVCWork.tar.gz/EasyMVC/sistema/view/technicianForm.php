<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<form method="POST" action="">
    <label for='cpf_cnpj'>cpf_cnpj:</label>
<input type='text' name='cpf_cnpj' id='cpf_cnpj' required>
<label for='name'>name:</label>
<input type='text' name='name' id='name' required>
<label for='address'>address:</label>
<input type='text' name='address' id='address' required>
<label for='phone'>phone:</label>
<input type='text' name='phone' id='phone' required>
<label for='crea'>crea:</label>
<input type='text' name='crea' id='crea' required>
<label for='email'>email:</label>
<input type='text' name='email' id='email' required>
<label for='password'>password:</label>
<input type='text' name='password' id='password' required>

    <button type="submit">Enviar</button>
</form>
</body>
</html>