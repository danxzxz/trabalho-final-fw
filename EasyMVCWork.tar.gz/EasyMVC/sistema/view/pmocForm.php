<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<form method="POST" action="">
    <label for='name'>name:</label>
<input type='text' name='name' id='name' required>
<label for='creation_date'>creation_date:</label>
<input type='text' name='creation_date' id='creation_date' required>
<label for='service_address'>service_address:</label>
<input type='text' name='service_address' id='service_address' required>
<label for='id_technician'>id_technician:</label>
<input type='number' name='id_technician' id='id_technician' required>
<label for='id_client'>id_client:</label>
<input type='number' name='id_client' id='id_client' required>

    <button type="submit">Enviar</button>
</form>
</body>
</html>