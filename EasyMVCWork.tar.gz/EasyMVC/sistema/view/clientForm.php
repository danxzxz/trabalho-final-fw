<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<form method="POST" action="">
    <label for='name'>name:</label>
<input type='text' name='name' id='name' required>
<label for='phone'>phone:</label>
<input type='text' name='phone' id='phone' required>

    <button type="submit">Enviar</button>
</form>
</body>
</html>