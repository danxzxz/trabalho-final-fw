<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
<form method="POST" action="">
    <label for='brand'>brand:</label>
<input type='text' name='brand' id='brand' required>
<label for='btus'>btus:</label>
<input type='number' name='btus' id='btus' required>
<label for='description'>description:</label>
<input type='text' name='description' id='description' required>
<label for='location'>location:</label>
<input type='text' name='location' id='location' required>
<label for='id_pmoc'>id_pmoc:</label>
<input type='number' name='id_pmoc' id='id_pmoc' required>

    <button type="submit">Enviar</button>
</form>
</body>
</html>